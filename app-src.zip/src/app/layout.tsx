import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const dseg7 = localFont({
  src: "../../node_modules/dseg/fonts/DSEG7-Classic/DSEG7Classic-Bold.woff2",
  variable: "--font-dseg7",
  display: "swap",
});

export const metadata: Metadata = {
  title: "FWAnime - Track, Discover & Share Anime and Manga",
  description:
    "FWAnime — track, discover and share anime and manga with other fans using the AniList GraphQL API.",
  openGraph: {
    title: "FWAnime",
    description: "Discover, track and share anime and manga.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={dseg7.variable}>
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Overpass:wght@300;400;600;700;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Navbar />
        <main className="pt-[60px]">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
